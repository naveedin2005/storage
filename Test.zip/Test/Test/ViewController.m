//
//  ViewController.m
//  Test
//
//  Created by Alex Dunn on 12/17/14.
//  Copyright © 2014 Apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // Do stuff here
    });
    
    dispatch_once(&onceToken, ^{
        if (1 == 1) {
            // Do stuff here
        }
    });
    
}

@end
